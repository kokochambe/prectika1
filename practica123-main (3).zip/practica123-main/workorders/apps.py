from django.apps import AppConfig


class WorkOrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workorders'
    verbose_name = 'Наряды-заказы'
